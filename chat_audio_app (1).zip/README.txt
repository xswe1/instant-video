# ChatWave — Firebase Chat + Audio Call

## What is included
- Firebase Email/Password authentication
- User list
- Real-time one-to-one Firestore chat
- WebRTC browser-to-browser audio calling
- Firebase Firestore signaling for calls
- Mute / hang up
- Responsive UI

## Setup
1. Create a Firebase project.
2. Add a Web App in Firebase.
3. Enable Authentication > Sign-in method > Email/Password.
4. Create a Cloud Firestore database.
5. Paste your Firebase web config into `index.html` where `firebaseConfig` is defined.
6. Publish `firestore.rules` in Firestore > Rules.
7. Serve the folder from a web server (Firebase Hosting, VS Code Live Server, etc.). Microphone access is normally available on HTTPS or localhost.
8. Open the app in two browser sessions and create two accounts.
9. Select the other user, send messages, and test the audio call.

## Important
This is a serverless Firebase architecture: there is no custom Node.js backend to maintain. Firebase Authentication and Firestore provide the cloud services.

The included WebRTC configuration uses public STUN servers. Some networks require a TURN server for reliable calls behind restrictive NAT/firewalls. A TURN service can be added later without changing the chat architecture.

## Security
Do not publish permissive Firestore rules such as `allow read, write: if true;`. Use the supplied rules as a starting point and test them in the Firebase Rules simulator before production.
